# Installation
> `npm install --save @types/cucumber`

# Summary
This package contains type definitions for cucumber-js (https://github.com/cucumber/cucumber-js).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/cucumber

Additional Details
 * Last updated: Wed, 08 Mar 2017 04:58:10 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Abraão Alves <https://github.com/abraaoalves>, Jan Molak <https://github.com/jan-molak>.
